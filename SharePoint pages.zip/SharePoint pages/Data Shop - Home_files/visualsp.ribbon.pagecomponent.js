﻿// Register the namespace for the PageComponent class
Type.registerNamespace('VisualSP.Ribbon');

// Initialize the base elements
VisualSP.Ribbon.PageComponent = function () {
    VisualSP.Ribbon.PageComponent.initializeBase(this);
}

// This function is called by the script added by the delegate control.
VisualSP.Ribbon.PageComponent.initialize = function () {
    ExecuteOrDelayUntilScriptLoaded(Function.createDelegate(null, VisualSP.Ribbon.PageComponent.initializePageComponent), 'SP.Ribbon.js');
}

// Get the PageManager object and add the page component using addPageComponent.
VisualSP.Ribbon.PageComponent.initializePageComponent = function () {
    var ribbonPageManager = SP.Ribbon.PageManager.get_instance();
    if (null !== ribbonPageManager) {
        ribbonPageManager.addPageComponent(VisualSP.Ribbon.PageComponent.instance);
        ribbonPageManager.get_focusManager().requestFocusForComponent(this.instance);
    }
}

VisualSP.Ribbon.PageComponent.prototype = {
    init: function () { },

    getFocusedCommands: function () {
        return [];
    },
    getGlobalCommands: function () {
        // Call the function registered in the delegate control
        if (typeof getVisualSPWebPartGlobalCommands == 'function') {
            return getVisualSPWebPartGlobalCommands();
        }
        if (typeof getVisualSPGlobalCommands == 'function') {
            return getVisualSPGlobalCommands();
        }
        return [];
    },
    isFocusable: function () {
        return true;
    },

    receiveFocus: function () {
        return true;
    },

    yieldFocus: function () {
        return true;
    },

    canHandleCommand: function (commandId) {
        // Call the function registered in the delegate control
        if (typeof visualSPWebPartCommandEnabled == 'function') {
            return visualSPWebPartCommandEnabled(commandId);
        }
        if (typeof visualSPCommandEnabled == 'function') {
            return visualSPCommandEnabled(commandId);
        }
        return false;
    },

    handleCommand: function (commandId, properties, sequence) {
        // Call the function registered in the delegate control
        if (typeof handleVisualSPWebPartCommand == 'function') {
            return handleVisualSPWebPartCommand(commandId, properties, sequence);
        }
        if (typeof handleVisualSPCommand == 'function') {
            return handleVisualSPCommand(commandId, properties, sequence);
        }
        return null;
    }
}

// Register the PageComponent class and set it's base class as CUI.Page.PageComponent
VisualSP.Ribbon.PageComponent.registerClass('VisualSP.Ribbon.PageComponent', CUI.Page.PageComponent);
// Set the PageComponent.instance variable to a new instance of the PageComponent class
VisualSP.Ribbon.PageComponent.instance = new VisualSP.Ribbon.PageComponent();
// Notify waiting jobs that this script has finished loading.
NotifyScriptLoadedAndExecuteWaitingJobs("VisualSP.Ribbon.PageComponent.js");