﻿//**********************************
// Status bar scripts used to display Warning messages to end users.
// The goal is to show users any planned downtime/outage
//**********************************
var _statusID;
var _textID;
var _endDate;

// Function used to show the message until endDate
// textID is used to track cookie information
function ShowInfo(textID, text, endDate) 
{
    var cookieValue = xomReadCookie(textID);
    var showMessage = true;

    _textID = textID;
    _endDate = endDate;

    if (cookieValue == null) {
        showMessage = true;

        XomSetCookie(textID, "showMessage", endDate);
    }
    else {
        if (cookieValue == "dismiss") {
            showMessage = false;
        }
    }

    if (showMessage) {
        var dismissButton = "&nbsp;&nbsp;<input type=\"button\" onclick=\"Javascript:DismissMessage()\" value=\"Dismiss\" class=\"UserButton\" >";

        _statusID = SP.UI.Status.addStatus("", text + dismissButton, true);
        SP.UI.Status.setStatusPriColor(_statusID, "yellow");
    }
}

// Append information to the Status message
function AppendInfo(text) {
    SP.UI.Status.appendStatus(_statusID, " Next : ", text, false);
    SP.UI.Status.setStatusPriColor(_statusID, "blue");
}

// Hide the message and update cookie
function DismissMessage() {
    SP.UI.Status.removeStatus(_statusID);
    XomSetCookie(_textID, "dismiss", _endDate);
}

// Helper messages to deal with Cookies
function XomSetCookie(name, value, endDate) 
{
    if (endDate) {
        var expires = "; expires=" + endDate.toGMTString();
    }
    else var expires = "";
    document.cookie = name + "=" + value + expires + "; path=/";
}

function xomReadCookie(name) {
    var nameEQ = name + "=";
    var cookies = document.cookie.split(';');
    for (var i = 0; i < cookies.length; i++) 
    {
        var item = cookies[i];
        while (item.charAt(0) == ' ') item = item.substring(1, item.length);
        if (item.indexOf(nameEQ) == 0) return item.substring(nameEQ.length, item.length);
    }
    return null;
}

function xomDeleteCookie(name) {
    var date = new Date();
    date.setDate(date.getDate() - 1);

    XomSetCookie(name, "dismiss", date); // Set to an expired date
}

